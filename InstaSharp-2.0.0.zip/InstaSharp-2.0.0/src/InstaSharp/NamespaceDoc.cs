﻿
namespace InstaSharp
{ 
    /// <summary>
    /// The Instasharp Api Library. Allowing you to interact with Instagram
    /// </summary>
    internal static class NamespaceDoc
    {
    }
}
