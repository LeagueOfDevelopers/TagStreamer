﻿
namespace InstaSharp.Endpoints
{ 
    /// <summary>
    /// The Endpoints. These are the services you use to interact with Instagram
    /// </summary>
    internal static class NamespaceDoc
    {
    }
}
