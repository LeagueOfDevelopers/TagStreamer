﻿namespace InstaSharp.Models
{  
    /// <summary>
    /// The Domain Models
    /// </summary>
    internal static class NamespaceDoc
    {
    }
}
