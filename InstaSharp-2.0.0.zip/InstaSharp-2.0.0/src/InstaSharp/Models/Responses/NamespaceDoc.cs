﻿namespace InstaSharp.Models.Responses
{
    /// <summary>
    /// The Response Models
    /// </summary>
    internal static class NamespaceDoc
    {
    }
}
