﻿namespace InstaSharp.Models
{
    public class Position
    {
        public float Y { get; set; }
        public float X { get; set; }
    }
}