﻿namespace InstaSharp.Models
{
    public class UserInPhoto
    {
        public Position Position { get; set; }
        public UserInfo User { get; set; }
    }
}
